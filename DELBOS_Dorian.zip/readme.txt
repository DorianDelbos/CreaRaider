CreaRaider par DELBOS Dorian

Touches :
- Movement : ZQSD
- Jump : space
- Interact : E
- Map : Tab

Comportements :
- en cas de game over, la scene ce reset
- en cas de victoire (après la dernière scène très reconnaissable que je ne vais pas spoil), la scene ce reset